# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 14:42:44 2024

@author: ADMIN
"""

import pandas as pd

s1 = pd.Series([10,50,20,4,78])
s2 = pd.Series([5,20,96,45,42])

add=s1+s2
print("add")
print(add)

sub=s1-s2
print("sub")
print(sub)

mul=s1*s2
print("mul")
print(mul)

div=s1/s2
print("div ")
print(div)
