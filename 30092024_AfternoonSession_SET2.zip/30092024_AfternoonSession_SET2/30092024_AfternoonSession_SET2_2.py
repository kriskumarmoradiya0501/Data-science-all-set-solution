# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 14:42:58 2024

@author: ADMIN
"""

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("housing_data.csv")

print("five record")
print(df.head(5))

print("sumary home price")
print(df["House Price"].describe())

r, c = df.shape
print("rows : ",r)
print("colum = ",c)

df["House Size (sqft)"] = df["House Size (sqft)"].fillna(1800)
print("missing data filled")
print(df)

av_price = df.groupby("Location")["House Price"].mean()
print(av_price)

plt.scatter(df["House Size (sqft)"], df["House Price"])
plt.title("price vs size")
plt.xlabel("size")
plt.ylabel("price")
plt.show()

df[df["Location"] == "Downtown"]["House Price"].plot(kind="hist", alpha=0.5, label="Down")
df[df["Location"] == "Suburbs"]["House Price"].plot(kind="hist", alpha=0.5, label="sub")
df[df["Location"] == "City"]["House Price"].plot(kind="hist", alpha=0.5, label="City")
plt.title("price on location")
plt.xlabel("House Price")
plt.show()
