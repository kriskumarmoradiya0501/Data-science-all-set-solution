# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 14:20:58 2024

@author: ADMIN
"""

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("employee_data.csv")

print("six record")
print(df.head(6))

print("Summery ")
print(df.describe())

r, c = df.shape
print("rows = ",r)
print("colams = ",c)

df["Salary"] = df["Salary"].fillna(df["Salary"].median())
df["Age"] = df["Age"].fillna(df["Age"].median())
print(df)

av_sal = df.groupby("Department")["Salary"].mean()
print(av_sal)

plt.hist(df["Age"], bins=5)
plt.title("distribushion of age")
plt.xlabel("age")
plt.grid(axis="y")
plt.show()

dept_counts = df["Department"].value_counts()
plt.figure(figsize=(8, 8))
plt.pie(dept_counts, labels=dept_counts.index)
plt.title("proportion ")
plt.show()
