# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 14:20:40 2024

@author: ADMIN
"""

import numpy as n

nv = n.zeros(10)

print(nv)

nv[5] = 11

print(nv)
