# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 15:34:44 2024

@author: ADMIN
"""

import numpy as np

first = np.random.randint(1, 11, size=5)

second = np.random.randint(11, 21, size=5)

add = first+second

print("first:", first)
print("second:", second)

print("add:",add)
