# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 15:35:23 2024

@author: ADMIN
"""

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("singerdata.csv")

print("five record")
print(df.tail(5))

print("Summary")
print(df.describe())

r, c = df.shape
print("rows : ",r)
print("colum = ",c)

df['Albums Released'] = df['Albums Released'].fillna(df['Albums Released'].median())
print("missed values are filled")
print(df)

av_album = df.groupby("Genre")["Albums Released"].mean()
print(av_album)

av_album.plot(kind='bar',title="Average albums")
plt.xlabel('Genre')
plt.ylabel('Average Albums Released')
plt.show()

genre_counts = df['Genre'].value_counts()
genre_counts.plot(kind='pie', title="Proportion ")
plt.ylabel('')
plt.show()