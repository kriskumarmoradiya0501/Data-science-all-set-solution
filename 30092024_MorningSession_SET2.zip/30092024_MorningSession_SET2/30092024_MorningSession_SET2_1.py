# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 15:53:15 2024

@author: ADMIN
"""

import numpy as np

a1 = np.array([[1,2,3],[4,5,6]])
a2 = np.array([[7,8],[9,10],[11,12]])

dot1 = np.dot(a1, a2)

print("arrauy 1 : ", a1) 
print("arrauy 2 : ", a2)
print("Dot ", dot1)
