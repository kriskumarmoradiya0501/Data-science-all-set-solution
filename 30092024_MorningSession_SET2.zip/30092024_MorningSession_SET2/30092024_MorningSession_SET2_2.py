# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 15:53:32 2024

@author: ADMIN
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv('sales_data.csv')
print("five records")
print(df.head())

print("Summary")
print(df.describe())

r, c = df.shape
print("rows : ",r)
print("colum = ",c)


df['Sales Amount'] = df['Sales Amount'].fillna(df['Sales Amount'].mean())
df['Quantity'] = df['Quantity'].fillna(df['Quantity'].mean())
df['Region'] = df['Region'].fillna(df['Region'].mode()[0])
df['Product Category'] = df['Product Category'].fillna(df['Product Category'].mode()[0])
print("missed value filled")

df['Total Sales'] = df['Sales Amount'] * df['Quantity']
tlt_sal = df.groupby("Product Category")["Total Sales"].sum()
print("total sale by categories")
print(tlt_sal)

sal_reg = df.groupby("Region")["Total Sales"].sum()
print(sal_reg)

sal_reg.plot(kind='bar')

plt.title('sales per region')
plt.xlabel('region')
plt.ylabel('sales')

plt.show()

plt.scatter(df['Sales Amount'], df['Quantity'])
plt.title('amount vs qty')
plt.xlabel('sale amount')
plt.ylabel('qty')
plt.show()
