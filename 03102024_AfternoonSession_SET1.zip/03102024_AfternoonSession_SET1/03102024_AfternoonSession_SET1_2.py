# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 13:22:40 2024

@author: ADMIN
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv("purchase_data.csv")
print("five records")
print(df.head())

print("\nSummary")
print(df["Purchase Amount"].describe())

r, c = df.shape
print("Rows: ",r)
print("Columns: "+c)

for col in ["Purchase Amount", "Age"]:
    mode_value = df[col].mode()[0]
    df[col] = df[col].fillna(mode_value)

print(df[["Customer ID","Name","Age","Product Purchased","Purchase Amount","Purchase Date"]])


bins = [0, 18, 25, 35, 45, 60, 100]
lab2 = ["-18", "18-25", "26-35", "36-45", "46-60", "60+"]
df["age group"] = pd.cut(df["Age"], bins=bins, labels=lab2, right=False)

av_group = df.groupby("age group",observed=False)["Purchase Amount"].mean()
print(av_group)

av_group.plot(kind="line", marker="o", title="Purchase Amount vs. Age Group")
plt.xlabel("Customer Age Group")
plt.ylabel("Average Purchase Amount")
plt.grid()
plt.show()
