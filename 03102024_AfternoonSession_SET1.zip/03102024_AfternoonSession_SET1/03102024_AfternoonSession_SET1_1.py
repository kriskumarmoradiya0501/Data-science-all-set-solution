# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 13:20:30 2024

@author: ADMIN
"""

import numpy as n

nv = n.zeros(10)

print(nv)

nv[3] = 15

print(nv)
